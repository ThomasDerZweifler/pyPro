#ifndef gui_h
#define gui_h

#include <gtk/gtk.h>

extern gint	saveDialog(void);

#endif
