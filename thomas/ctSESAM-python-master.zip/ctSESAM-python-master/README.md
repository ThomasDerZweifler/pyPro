# ctSESAM-python
This is the command line Python version of the c't password manager.
